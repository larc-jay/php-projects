
<div class="wt-line"></div>
<div class="footer footer-inner-bg">
      <div class="container">
        <p class="text-muted">&copy 2017, all right reserved</p>
      </div>
 </div>
<?php echo "</body></html>"; ?>